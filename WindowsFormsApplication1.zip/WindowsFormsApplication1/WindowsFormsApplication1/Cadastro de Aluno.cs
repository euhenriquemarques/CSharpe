﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Cadastro_de_Aluno : Form
    {
        public Cadastro_de_Aluno()
        {
            InitializeComponent();
        }

        private void Cadastro_de_Aluno_Load(object sender, EventArgs e)
        {
            btnExcluir.Enabled = false;
            btnSalvar.Enabled = false;
            txbNomeAluno.Enabled = false;
            txbCursoAluno.Enabled = false;
            btnProcurar.Enabled = false;
            btnNovo.Enabled = true;
            txbCursoAluno.Enabled = false;
            txbProcurar.Enabled = true;
            txbCodigoAluno.Enabled = false;
            
        }
        
        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            btnExcluir.Enabled = false;
            btnSalvar.Enabled = true;
            txbNomeAluno.Enabled = true;
            txbCursoAluno.Enabled = true;
            btnProcurar.Enabled = false;
            btnNovo.Enabled = false;
            txbCursoAluno.Enabled = true;
            txbProcurar.Enabled = false;
            txbCodigoAluno.Enabled = false;
        }

        private void txbProcurar_Click(object sender, EventArgs e)
        {
            btnExcluir.Enabled = false;
            btnSalvar.Enabled = false;
            txbNomeAluno.Enabled = false;
            txbCursoAluno.Enabled = false;
            btnProcurar.Enabled = true;
            btnNovo.Enabled = true;
            txbCursoAluno.Enabled = false;
            txbProcurar.Enabled = true;
            txbCodigoAluno.Enabled = false;
        }

      
    }
}
