﻿namespace WindowsFormsApplication1
{
    partial class Orientador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Orientador));
            this.dgOrientador = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txbCodigoOrientador = new System.Windows.Forms.TextBox();
            this.txbCursoOrientador = new System.Windows.Forms.TextBox();
            this.txbNomeOrientador = new System.Windows.Forms.TextBox();
            this.txbProjetoOrientador = new System.Windows.Forms.TextBox();
            this.txbOrientadorOrientador = new System.Windows.Forms.TextBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btnSalvar = new System.Windows.Forms.ToolStripButton();
            this.btnExcluir = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.txbProcurar = new System.Windows.Forms.ToolStripTextBox();
            this.btnProcurar = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.dgOrientador)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgOrientador
            // 
            this.dgOrientador.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgOrientador.Location = new System.Drawing.Point(12, 155);
            this.dgOrientador.Name = "dgOrientador";
            this.dgOrientador.Size = new System.Drawing.Size(498, 126);
            this.dgOrientador.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Código";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Nome";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Curso";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 109);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Projeto";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(0, 132);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Orientador";
            // 
            // txbCodigoOrientador
            // 
            this.txbCodigoOrientador.Location = new System.Drawing.Point(57, 37);
            this.txbCodigoOrientador.Name = "txbCodigoOrientador";
            this.txbCodigoOrientador.Size = new System.Drawing.Size(76, 20);
            this.txbCodigoOrientador.TabIndex = 6;
            // 
            // txbCursoOrientador
            // 
            this.txbCursoOrientador.Location = new System.Drawing.Point(57, 83);
            this.txbCursoOrientador.Name = "txbCursoOrientador";
            this.txbCursoOrientador.Size = new System.Drawing.Size(208, 20);
            this.txbCursoOrientador.TabIndex = 7;
            // 
            // txbNomeOrientador
            // 
            this.txbNomeOrientador.Location = new System.Drawing.Point(57, 60);
            this.txbNomeOrientador.Name = "txbNomeOrientador";
            this.txbNomeOrientador.Size = new System.Drawing.Size(208, 20);
            this.txbNomeOrientador.TabIndex = 8;
            // 
            // txbProjetoOrientador
            // 
            this.txbProjetoOrientador.Location = new System.Drawing.Point(57, 106);
            this.txbProjetoOrientador.Name = "txbProjetoOrientador";
            this.txbProjetoOrientador.Size = new System.Drawing.Size(453, 20);
            this.txbProjetoOrientador.TabIndex = 9;
            // 
            // txbOrientadorOrientador
            // 
            this.txbOrientadorOrientador.Location = new System.Drawing.Point(57, 129);
            this.txbOrientadorOrientador.Name = "txbOrientadorOrientador";
            this.txbOrientadorOrientador.Size = new System.Drawing.Size(453, 20);
            this.txbOrientadorOrientador.TabIndex = 10;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnSalvar,
            this.btnExcluir,
            this.toolStripLabel1,
            this.txbProcurar,
            this.btnProcurar});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(522, 25);
            this.toolStrip1.TabIndex = 11;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // btnSalvar
            // 
            this.btnSalvar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSalvar.Image = ((System.Drawing.Image)(resources.GetObject("btnSalvar.Image")));
            this.btnSalvar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(23, 22);
            this.btnSalvar.Text = "toolStripButton1";
            // 
            // btnExcluir
            // 
            this.btnExcluir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnExcluir.Image = ((System.Drawing.Image)(resources.GetObject("btnExcluir.Image")));
            this.btnExcluir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(23, 22);
            this.btnExcluir.Text = "toolStripButton2";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(46, 22);
            this.toolStripLabel1.Text = "Codigo";
            // 
            // txbProcurar
            // 
            this.txbProcurar.Name = "txbProcurar";
            this.txbProcurar.Size = new System.Drawing.Size(100, 25);
            // 
            // btnProcurar
            // 
            this.btnProcurar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnProcurar.Image = ((System.Drawing.Image)(resources.GetObject("btnProcurar.Image")));
            this.btnProcurar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnProcurar.Name = "btnProcurar";
            this.btnProcurar.Size = new System.Drawing.Size(23, 22);
            this.btnProcurar.Text = "toolStripButton3";
            // 
            // Orientador
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(522, 288);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.txbOrientadorOrientador);
            this.Controls.Add(this.txbProjetoOrientador);
            this.Controls.Add(this.txbNomeOrientador);
            this.Controls.Add(this.txbCursoOrientador);
            this.Controls.Add(this.txbCodigoOrientador);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgOrientador);
            this.Name = "Orientador";
            this.Text = "Cadastro Orientador";
            this.Load += new System.EventHandler(this.Orientador_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgOrientador)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgOrientador;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txbCodigoOrientador;
        private System.Windows.Forms.TextBox txbCursoOrientador;
        private System.Windows.Forms.TextBox txbNomeOrientador;
        private System.Windows.Forms.TextBox txbProjetoOrientador;
        private System.Windows.Forms.TextBox txbOrientadorOrientador;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton btnSalvar;
        private System.Windows.Forms.ToolStripButton btnExcluir;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripTextBox txbProcurar;
        private System.Windows.Forms.ToolStripButton btnProcurar;
    }
}

