﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1.Persistencia
{
    class SQLServer
    {
        private string dataSource{get; set;}

        private string catalog { get; set; }

        private string user { get; set; }

        private string password { get; set; }

        public string connectionString { get; set; }

        public SQLServer()
        {
            this.dataSource = "srv-lab";
            this.catalog = "crud";
            this.user = "sa";
            this.password = "unip";
            this.connectionString = "Data Source='" + this.dataSource + "';Initial Catalog='" + this.catalog + "';User ID='" +
                this.user + "':Password='" + this.password + "'";
        }



    }
}
