﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1.Persistencia
{
    class AlunoPersistencia
    {

        public AlunoPersistencia() { }


        public string salvarRegistroSQL(string sql, bool registroNovo)
        {
            SQLServer conexao = new SQLServer();
            SqlConnection con = new SqlConnection(conexao.connectionString);
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;
            con.Open();
             

        try{
        int i = cmd.ExecuteNonQuery();
        if(i>0 && registroNovo)
            return "Cadastro realizado com sucesso!"
        else if(i >0 && !registroNovo)
            return "Cadastro Atualizado com Sucesso!"
        else 
            return "Erro ao Salvar Registro"
        }
            catch(Exception ex)
            {
                return "Erro: "+ex.ToString();
            }
            finally
        {
            con.Close();
        }

    
    }

    }
}
