﻿namespace WindowsFormsApplication1
{
    partial class Professor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Professor));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btnSalvar = new System.Windows.Forms.ToolStripButton();
            this.btnExcluir = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.txtProcura = new System.Windows.Forms.ToolStripTextBox();
            this.btnProcura = new System.Windows.Forms.ToolStripButton();
            this.txbNomeProfessor = new System.Windows.Forms.TextBox();
            this.txbDiplomaOrientador = new System.Windows.Forms.TextBox();
            this.txbCodigoProfessor = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dtProfessor = new System.Windows.Forms.DataGridView();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtProfessor)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnSalvar,
            this.btnExcluir,
            this.toolStripLabel1,
            this.txtProcura,
            this.btnProcura});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(284, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // btnSalvar
            // 
            this.btnSalvar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSalvar.Image = ((System.Drawing.Image)(resources.GetObject("btnSalvar.Image")));
            this.btnSalvar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(23, 22);
            this.btnSalvar.Text = "toolStripButton1";
            // 
            // btnExcluir
            // 
            this.btnExcluir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnExcluir.Image = ((System.Drawing.Image)(resources.GetObject("btnExcluir.Image")));
            this.btnExcluir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(23, 22);
            this.btnExcluir.Text = "toolStripButton2";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(46, 22);
            this.toolStripLabel1.Text = "Codigo";
            // 
            // txtProcura
            // 
            this.txtProcura.Name = "txtProcura";
            this.txtProcura.Size = new System.Drawing.Size(100, 25);
            // 
            // btnProcura
            // 
            this.btnProcura.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnProcura.Image = ((System.Drawing.Image)(resources.GetObject("btnProcura.Image")));
            this.btnProcura.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnProcura.Name = "btnProcura";
            this.btnProcura.Size = new System.Drawing.Size(23, 22);
            this.btnProcura.Text = "toolStripButton3";
            // 
            // txbNomeProfessor
            // 
            this.txbNomeProfessor.Location = new System.Drawing.Point(52, 51);
            this.txbNomeProfessor.Name = "txbNomeProfessor";
            this.txbNomeProfessor.Size = new System.Drawing.Size(208, 20);
            this.txbNomeProfessor.TabIndex = 14;
            // 
            // txbDiplomaOrientador
            // 
            this.txbDiplomaOrientador.Location = new System.Drawing.Point(52, 74);
            this.txbDiplomaOrientador.Name = "txbDiplomaOrientador";
            this.txbDiplomaOrientador.Size = new System.Drawing.Size(208, 20);
            this.txbDiplomaOrientador.TabIndex = 13;
            // 
            // txbCodigoProfessor
            // 
            this.txbCodigoProfessor.Location = new System.Drawing.Point(52, 28);
            this.txbCodigoProfessor.Name = "txbCodigoProfessor";
            this.txbCodigoProfessor.Size = new System.Drawing.Size(76, 20);
            this.txbCodigoProfessor.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Diploma";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Nome";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Código";
            // 
            // dtProfessor
            // 
            this.dtProfessor.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtProfessor.Location = new System.Drawing.Point(9, 113);
            this.dtProfessor.Name = "dtProfessor";
            this.dtProfessor.Size = new System.Drawing.Size(263, 126);
            this.dtProfessor.TabIndex = 15;
            // 
            // Professor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 245);
            this.Controls.Add(this.dtProfessor);
            this.Controls.Add(this.txbNomeProfessor);
            this.Controls.Add(this.txbDiplomaOrientador);
            this.Controls.Add(this.txbCodigoProfessor);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.toolStrip1);
            this.Name = "Professor";
            this.Text = "Professor";
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtProfessor)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton btnExcluir;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripTextBox txtProcura;
        private System.Windows.Forms.ToolStripButton btnProcura;
        private System.Windows.Forms.TextBox txbNomeProfessor;
        private System.Windows.Forms.TextBox txbDiplomaOrientador;
        private System.Windows.Forms.TextBox txbCodigoProfessor;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dtProfessor;
        private System.Windows.Forms.ToolStripButton btnSalvar;
    }
}